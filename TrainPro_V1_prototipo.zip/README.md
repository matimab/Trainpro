# TrainPro V1

Prototipo web responsive de la app de entrenamiento.

Incluye:
- Panel de profesor
- Alumnos
- Planificaciones (macro/meso/micro/sesión como estructura visual)
- Desbloqueo de sesiones
- Biblioteca de ejercicios y videos (campo de enlace)
- Plantillas
- Evaluaciones: peso, perímetros, % grasa y fotos comparativas
- Diseño responsive para celular

## Probar
Abrí `index.html` en un navegador.

## Próximo paso
Esta V1 es un prototipo funcional de interfaz. La siguiente etapa es conectarla a una base de datos (Supabase), autenticación real Profesor/Alumno y persistencia de datos.
